"""
Advanced Lane Detection Pipeline
=================================
Extends the naokishibuya/car-finding-lane-lines base with:
  - Adaptive preprocessing for adverse weather (rain, fog, night)
  - Polynomial curve fitting (not just straight Hough lines)
  - Temporal smoothing via Kalman-like weighted history
  - Lane departure warning system
  - Road surface quality estimation (wet / dry / icy proxy)
  - Vanishing-point based dynamic ROI
  - Confidence scoring per frame

Author : (your name)
Course : Computer Vision — aligned to Classical CV syllabus
"""

import cv2
import numpy as np
from collections import deque
from dataclasses import dataclass, field
from typing import Optional, Tuple, List
import logging

logger = logging.getLogger(__name__)


# ─────────────────────────── data structures ──────────────────────────────────

@dataclass
class LaneLine:
    """Represents one detected lane boundary."""
    poly_coeffs: np.ndarray          # 2nd-degree polynomial ax²+bx+c
    base_x: float                    # x-position at image bottom
    confidence: float = 1.0          # [0,1] detection quality
    curvature_m: float = 0.0         # radius of curvature in metres
    detected: bool = True


@dataclass
class FrameResult:
    """All outputs produced for a single frame."""
    left: Optional[LaneLine] = None
    right: Optional[LaneLine] = None
    lane_centre_offset_m: float = 0.0
    departure_warning: bool = False
    weather_mode: str = "normal"       # normal | foggy | rainy | night
    road_wetness: str = "dry"          # dry | wet | icy
    annotated: Optional[np.ndarray] = None


# ──────────────────────── weather / scene classifier ──────────────────────────

class SceneClassifier:
    """
    Classifies lighting and weather conditions using:
      - Mean luminance  (histogram analysis  → night detection)
      - Contrast / std  (fog reduces contrast → fog detection)
      - Saturation drop (rain desaturates scene)

    Classical CV techniques used:
      HSL color space analysis, histogram statistics, LBP-inspired
      texture roughness for road wetness proxy.
    """

    def classify(self, frame_bgr: np.ndarray) -> Tuple[str, str]:
        """Returns (weather_mode, road_wetness)."""
        hls = cv2.cvtColor(frame_bgr, cv2.COLOR_BGR2HLS)
        l_channel = hls[:, :, 1].astype(np.float32)
        s_channel = hls[:, :, 2].astype(np.float32)

        mean_l   = float(np.mean(l_channel))
        std_l    = float(np.std(l_channel))
        mean_s   = float(np.mean(s_channel))

        # ── weather mode ──
        if mean_l < 50:
            weather = "night"
        elif std_l < 30 and mean_l > 120:
            weather = "foggy"
        elif mean_s < 40 and mean_l < 150:
            weather = "rainy"
        else:
            weather = "normal"

        # ── road wetness: high specular reflection in road ROI ──
        h, w = frame_bgr.shape[:2]
        road_roi = l_channel[int(h * 0.6):, :]
        brightness_var = float(np.var(road_roi))
        wetness = "wet" if brightness_var > 1200 else "dry"

        return weather, wetness


# ─────────────────────── image enhancement module ─────────────────────────────

class ImageEnhancer:
    """
    Adaptive preprocessing aligned to syllabus topics:
      - Histogram Equalisation / CLAHE  (Image Enhancement)
      - Gaussian / Bilateral filtering  (Filtering & Convolution)
      - Dehazing via Dark Channel Prior  (Image Restoration)
      - Gamma correction for night scenes
    """

    def __init__(self):
        self.clahe = cv2.createCLAHE(clipLimit=3.0, tileGridSize=(8, 8))

    # ── public entry point ──
    def enhance(self, frame_bgr: np.ndarray, weather: str) -> np.ndarray:
        if weather == "foggy":
            frame_bgr = self._dehaze(frame_bgr)
        elif weather == "night":
            frame_bgr = self._gamma_correct(frame_bgr, gamma=2.0)
            frame_bgr = self._clahe_enhance(frame_bgr)
        elif weather == "rainy":
            frame_bgr = self._bilateral_denoise(frame_bgr)
            frame_bgr = self._clahe_enhance(frame_bgr)
        return frame_bgr

    # ── CLAHE on luminance channel ──
    def _clahe_enhance(self, bgr: np.ndarray) -> np.ndarray:
        hls = cv2.cvtColor(bgr, cv2.COLOR_BGR2HLS)
        hls[:, :, 1] = self.clahe.apply(hls[:, :, 1])
        return cv2.cvtColor(hls, cv2.COLOR_HLS2BGR)

    # ── Dark Channel Prior dehazing (He et al. simplified) ──
    def _dehaze(self, bgr: np.ndarray) -> np.ndarray:
        norm = bgr.astype(np.float32) / 255.0
        dark = np.min(norm, axis=2)
        kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (15, 15))
        dark_ch = cv2.erode(dark, kernel)
        # estimate atmospheric light
        flat = dark_ch.flatten()
        idx = np.argsort(flat)[-int(0.001 * len(flat)):]
        rows, cols = np.unravel_index(idx, dark_ch.shape)
        atm = np.max(norm[rows, cols], axis=0)
        atm = np.clip(atm, 0.5, 1.0)
        # transmission map
        t = 1.0 - 0.9 * dark_ch
        t = np.maximum(t, 0.1)[:, :, np.newaxis]
        dehazed = (norm - atm) / t + atm
        return np.clip(dehazed * 255, 0, 255).astype(np.uint8)

    # ── gamma correction ──
    def _gamma_correct(self, bgr: np.ndarray, gamma: float = 1.5) -> np.ndarray:
        inv = 1.0 / gamma
        lut = (np.linspace(0, 1, 256) ** inv * 255).astype(np.uint8)
        return lut[bgr]

    # ── bilateral filter for rain noise ──
    def _bilateral_denoise(self, bgr: np.ndarray) -> np.ndarray:
        return cv2.bilateralFilter(bgr, d=9, sigmaColor=75, sigmaSpace=75)


# ──────────────────────────── color thresholding ──────────────────────────────

class ColorThresholder:
    """
    Multi-colour-space lane mask extraction.

    Techniques (syllabus: Image Formation, Transformation):
      - HSL masking for white and yellow in varying illumination
      - LAB b-channel for yellow robustness under shadows
      - Adaptive thresholding fallback for night / glare
    """

    @staticmethod
    def threshold(bgr: np.ndarray, weather: str) -> np.ndarray:
        hls = cv2.cvtColor(bgr, cv2.COLOR_BGR2HLS)
        lab = cv2.cvtColor(bgr, cv2.COLOR_BGR2Lab)

        # ── White mask ──
        lower_w = np.array([0,   180, 0],   dtype=np.uint8)
        upper_w = np.array([255, 255, 255], dtype=np.uint8)
        white_mask = cv2.inRange(hls, lower_w, upper_w)

        # ── Yellow mask (HLS) ──
        lower_y = np.array([15,  30, 80], dtype=np.uint8)
        upper_y = np.array([35, 204, 255], dtype=np.uint8)
        yellow_hls = cv2.inRange(hls, lower_y, upper_y)

        # ── Yellow in LAB b-channel (more robust under shadows) ──
        b_ch = lab[:, :, 2]
        _, yellow_lab = cv2.threshold(b_ch, 155, 255, cv2.THRESH_BINARY)

        yellow_mask = cv2.bitwise_or(yellow_hls, yellow_lab)

        # ── Night / low-light: adaptive threshold on L channel ──
        if weather in ("night", "rainy"):
            l_ch = hls[:, :, 1]
            adaptive = cv2.adaptiveThreshold(
                l_ch, 255, cv2.ADAPTIVE_THRESH_GAUSSIAN_C,
                cv2.THRESH_BINARY, 51, -10
            )
            combined = cv2.bitwise_or(
                cv2.bitwise_or(white_mask, yellow_mask), adaptive
            )
        else:
            combined = cv2.bitwise_or(white_mask, yellow_mask)

        return combined


# ────────────────────────── edge detection wrapper ────────────────────────────

class EdgeDetector:
    """
    Canny edge detection with Sobel magnitude overlay.

    Syllabus: Image Representation & Description — Canny, LOG, DOG edges.
    """

    @staticmethod
    def detect(gray: np.ndarray, weather: str) -> np.ndarray:
        blur_k = 7 if weather in ("foggy", "rainy") else 5
        blurred = cv2.GaussianBlur(gray, (blur_k, blur_k), 0)

        # ── Canny ──
        low, high = (30, 90) if weather == "night" else (50, 150)
        canny = cv2.Canny(blurred, low, high)

        # ── Sobel magnitude (better for low contrast) ──
        sx = cv2.Sobel(blurred, cv2.CV_64F, 1, 0, ksize=3)
        sy = cv2.Sobel(blurred, cv2.CV_64F, 0, 1, ksize=3)
        sobel_mag = np.sqrt(sx**2 + sy**2)
        sobel_mag = np.clip(sobel_mag / sobel_mag.max() * 255, 0, 255).astype(np.uint8)
        _, sobel_thresh = cv2.threshold(sobel_mag, 50, 255, cv2.THRESH_BINARY)

        return cv2.bitwise_or(canny, sobel_thresh)


# ────────────────────── dynamic ROI & vanishing point ─────────────────────────

class ROISelector:
    """
    Computes a trapezoid ROI anchored at the estimated vanishing point.

    Syllabus: Image Segmentation, Projective Transformation.

    The vanishing point is found by intersecting Hough lines in the
    upper half — more robust than a fixed polygon.
    """

    def get_roi_mask(self, edge_img: np.ndarray) -> np.ndarray:
        h, w = edge_img.shape[:2]
        vp = self._estimate_vanishing_point(edge_img, h, w)
        vp_y = max(int(vp[1]), int(h * 0.35))

        pts = np.array([
            [int(w * 0.05), h],
            [int(vp[0] - w * 0.06), vp_y],
            [int(vp[0] + w * 0.06), vp_y],
            [int(w * 0.95), h],
        ], dtype=np.int32)

        mask = np.zeros_like(edge_img)
        cv2.fillPoly(mask, [pts], 255)
        return cv2.bitwise_and(edge_img, mask), pts

    def _estimate_vanishing_point(self, edge: np.ndarray,
                                  h: int, w: int) -> Tuple[float, float]:
        lines = cv2.HoughLinesP(edge, 1, np.pi / 180,
                                threshold=40, minLineLength=50, maxLineGap=150)
        if lines is None:
            return (w / 2, h * 0.4)

        intersections = []
        lines = lines[:, 0, :]
        for i in range(len(lines)):
            for j in range(i + 1, len(lines)):
                pt = self._line_intersection(lines[i], lines[j])
                if pt and 0 < pt[0] < w and h * 0.2 < pt[1] < h * 0.6:
                    intersections.append(pt)

        if not intersections:
            return (w / 2, h * 0.4)

        pts_arr = np.array(intersections)
        return (float(np.median(pts_arr[:, 0])), float(np.median(pts_arr[:, 1])))

    @staticmethod
    def _line_intersection(l1, l2):
        x1, y1, x2, y2 = l1
        x3, y3, x4, y4 = l2
        denom = (x1 - x2) * (y3 - y4) - (y1 - y2) * (x3 - x4)
        if abs(denom) < 1e-6:
            return None
        t = ((x1 - x3) * (y3 - y4) - (y1 - y3) * (x3 - x4)) / denom
        ix = x1 + t * (x2 - x1)
        iy = y1 + t * (y2 - y1)
        return (ix, iy)


# ─────────────────────── polynomial lane fitter ───────────────────────────────

class LaneFitter:
    """
    Fits 2nd-order polynomials to left / right lane pixels.

    Compared to the base repo (Hough + straight-line extrapolation),
    this handles curved roads via least-squares polynomial regression —
    a classical technique from numerical methods / pattern analysis.

    Syllabus: Pattern Analysis (Dimensionality Reduction, Classification),
              Image Representation (Orientation Histogram, Hough Transform).
    """

    def __init__(self, history_len: int = 12):
        self._left_history:  deque = deque(maxlen=history_len)
        self._right_history: deque = deque(maxlen=history_len)

    def fit(self, roi_edge: np.ndarray,
            h: int, w: int) -> Tuple[Optional[LaneLine], Optional[LaneLine]]:
        # ── Hough lines for initial lane pixel seeding ──
        lines = cv2.HoughLinesP(roi_edge, rho=1, theta=np.pi / 180,
                                threshold=20, minLineLength=20, maxLineGap=300)
        if lines is None:
            return self._from_history()

        left_pts, right_pts = self._segregate_lines(lines, h, w)
        left  = self._fit_side(left_pts,  h, w, self._left_history,  side="left")
        right = self._fit_side(right_pts, h, w, self._right_history, side="right")
        return left, right

    # ── split lines by slope / position ──
    @staticmethod
    def _segregate_lines(lines, h, w):
        left_pts, right_pts = [], []
        cx = w / 2
        for line in lines[:, 0, :]:
            x1, y1, x2, y2 = line
            if x2 == x1:
                continue
            slope = (y2 - y1) / (x2 - x1)
            if abs(slope) < 0.3:
                continue  # near-horizontal → noise
            # collect midpoint as sample
            mx, my = (x1 + x2) / 2, (y1 + y2) / 2
            # left lane: negative slope (y increases downward) AND left half
            if slope < 0 and mx < cx:
                left_pts.append((x1, y1))
                left_pts.append((x2, y2))
            elif slope > 0 and mx > cx:
                right_pts.append((x1, y1))
                right_pts.append((x2, y2))
        return left_pts, right_pts

    def _fit_side(self, pts: list, h: int, w: int,
                  history: deque, side: str) -> Optional[LaneLine]:
        if len(pts) < 4:
            # fall back to history
            if history:
                prev = history[-1]
                return LaneLine(poly_coeffs=prev.poly_coeffs,
                                base_x=prev.base_x,
                                confidence=max(0.0, prev.confidence - 0.15),
                                curvature_m=prev.curvature_m,
                                detected=False)
            return None

        arr = np.array(pts)
        ys, xs = arr[:, 1].astype(np.float64), arr[:, 0].astype(np.float64)
        try:
            coeffs = np.polyfit(ys, xs, 2)
        except np.linalg.LinAlgError:
            return None

        # ── temporal smoothing: exponential weighted average over history ──
        if history:
            weights = np.exp(np.linspace(-1, 0, len(history)))
            weights /= weights.sum()
            hist_coeffs = np.array([l.poly_coeffs for l in history])
            smooth = (np.sum(hist_coeffs * weights[:, None], axis=0) * 0.4
                      + coeffs * 0.6)
        else:
            smooth = coeffs

        base_x = float(np.polyval(smooth, h))
        curv   = self._curvature(smooth, h)
        conf   = min(1.0, len(pts) / 80.0)

        lane = LaneLine(poly_coeffs=smooth, base_x=base_x,
                        confidence=conf, curvature_m=curv)
        history.append(lane)
        return lane

    @staticmethod
    def _curvature(coeffs: np.ndarray, y_eval: int) -> float:
        """Radius of curvature in metres (assuming 30m/720px vertical)."""
        ym = 30 / 720
        xm = 3.7 / 700
        a, b = coeffs[0], coeffs[1]
        # scale to real world
        a_r = a * (xm / ym ** 2)
        b_r = b * (xm / ym)
        denom = (2 * a_r * y_eval * ym + b_r) ** 2
        if denom < 1e-6:
            return 9999.0
        return float(((1 + denom) ** 1.5) / abs(2 * a_r))

    def _from_history(self):
        left  = (self._left_history[-1]
                 if self._left_history else None)
        right = (self._right_history[-1]
                 if self._right_history else None)
        return left, right


# ─────────────────────── departure warning system ─────────────────────────────

class DepartureWarner:
    """
    Lane Departure Warning (LDW) — measures lateral offset of vehicle
    centre relative to lane centre.

    Syllabus: Motion Analysis — estimating displacement, spatial analysis.
    """
    CAMERA_CENTRE_M = 0.0   # camera assumed at vehicle centre
    LANE_WIDTH_M    = 3.7   # standard lane width (metres)
    WARNING_THRESH  = 0.4   # metres offset → trigger warning

    def analyse(self, left: Optional[LaneLine], right: Optional[LaneLine],
                h: int, w: int) -> Tuple[float, bool]:
        if left is None or right is None:
            return 0.0, False

        lane_centre_px = (left.base_x + right.base_x) / 2.0
        vehicle_centre_px = w / 2.0
        px_offset  = vehicle_centre_px - lane_centre_px
        xm_per_px  = self.LANE_WIDTH_M / abs(right.base_x - left.base_x + 1e-6)
        offset_m   = px_offset * xm_per_px
        warning    = abs(offset_m) > self.WARNING_THRESH
        return float(offset_m), warning


# ─────────────────────────── visualiser ───────────────────────────────────────

class Visualiser:
    """Draws all overlays onto the original frame."""

    @staticmethod
    def draw(frame: np.ndarray, result: FrameResult,
             roi_pts: Optional[np.ndarray] = None) -> np.ndarray:
        out = frame.copy()
        h, w = out.shape[:2]

        # ── filled lane region ──
        if result.left and result.right:
            overlay = out.copy()
            ys = np.linspace(h * 0.55, h, 60).astype(int)
            lx = np.clip(np.polyval(result.left.poly_coeffs,  ys).astype(int), 0, w - 1)
            rx = np.clip(np.polyval(result.right.poly_coeffs, ys).astype(int), 0, w - 1)
            pts_left  = np.stack([lx, ys], axis=1)
            pts_right = np.stack([rx, ys], axis=1)[::-1]
            poly_pts  = np.vstack([pts_left, pts_right])

            # colour by warning state
            colour = (0, 60, 220) if result.departure_warning else (0, 200, 100)
            cv2.fillPoly(overlay, [poly_pts], colour)
            cv2.addWeighted(overlay, 0.35, out, 0.65, 0, out)

            # ── draw lane lines ──
            for pts, c in [(pts_left, (255, 100, 0)), (pts_right[::-1], (0, 100, 255))]:
                for i in range(len(pts) - 1):
                    cv2.line(out, tuple(pts[i]), tuple(pts[i + 1]), c, 3)

        # ── HUD panel ──
        Visualiser._hud(out, result, h, w)
        return out

    @staticmethod
    def _hud(out, result, h, w):
        panel_h = 110
        panel = np.zeros((panel_h, w, 3), dtype=np.uint8)
        panel[:] = (20, 20, 20)

        def txt(s, x, y, colour=(200, 200, 200), scale=0.55):
            cv2.putText(panel, s, (x, y), cv2.FONT_HERSHEY_SIMPLEX,
                        scale, colour, 1, cv2.LINE_AA)

        # offset
        off = result.lane_centre_offset_m
        off_col = (0, 80, 255) if result.departure_warning else (0, 220, 120)
        txt(f"Lateral offset : {off:+.2f} m", 12, 22, off_col, 0.6)

        # curvature
        curv_str = "Straight"
        if result.left and result.left.curvature_m < 3000:
            curv_str = f"{result.left.curvature_m:.0f} m"
        txt(f"Curvature R    : {curv_str}", 12, 48, scale=0.55)

        # weather / wetness
        wc = {"normal": (180,200,180), "foggy": (200,200,100),
              "rainy": (100,150,255), "night": (140,100,220)}
        txt(f"Scene          : {result.weather_mode.upper()}  |  Road: {result.road_wetness.upper()}",
            12, 72, wc.get(result.weather_mode, (200, 200, 200)), 0.5)

        # confidence
        if result.left and result.right:
            conf = (result.left.confidence + result.right.confidence) / 2
            txt(f"Lane confidence: {conf * 100:.0f}%", 12, 96, scale=0.5)

        # departure banner
        if result.departure_warning:
            cv2.rectangle(panel, (w - 230, 4), (w - 4, 55), (0, 0, 180), -1)
            cv2.putText(panel, "⚠ LANE DEPARTURE", (w - 222, 36),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.65, (255, 255, 255), 2)

        out[:panel_h] = panel


# ─────────────────────────── main pipeline class ──────────────────────────────

class AdvancedLaneDetector:
    """
    End-to-end advanced lane detection pipeline.

    Pipeline stages
    ───────────────
    1. Scene classification       (weather / lighting)
    2. Adaptive enhancement       (CLAHE / dehazing / gamma)
    3. Colour thresholding        (HSL + LAB multi-space)
    4. Edge detection             (Canny + Sobel)
    5. Dynamic ROI masking        (vanishing-point driven)
    6. Polynomial lane fitting    (Hough seeding + poly-regression)
    7. Temporal smoothing         (exponentially weighted history)
    8. Lane departure analysis    (offset computation)
    9. Visualisation              (filled overlay + HUD)
    """

    def __init__(self):
        self.classifier = SceneClassifier()
        self.enhancer   = ImageEnhancer()
        self.roi        = ROISelector()
        self.fitter     = LaneFitter(history_len=15)
        self.warner     = DepartureWarner()

    def process_frame(self, frame_bgr: np.ndarray) -> FrameResult:
        h, w = frame_bgr.shape[:2]
        result = FrameResult()

        # 1. scene
        result.weather_mode, result.road_wetness = \
            self.classifier.classify(frame_bgr)

        # 2. enhance
        enhanced = self.enhancer.enhance(frame_bgr.copy(), result.weather_mode)

        # 3. colour mask
        colour_mask = ColorThresholder.threshold(enhanced, result.weather_mode)

        # 4. edges (on grayscale of enhanced)
        gray  = cv2.cvtColor(enhanced, cv2.COLOR_BGR2GRAY)
        edges = EdgeDetector.detect(gray, result.weather_mode)

        # 5. combine colour + edge information
        combined = cv2.bitwise_or(colour_mask, edges)

        # 6. ROI
        roi_img, roi_pts = self.roi.get_roi_mask(combined)

        # 7. fit lanes
        result.left, result.right = self.fitter.fit(roi_img, h, w)

        # 8. departure
        result.lane_centre_offset_m, result.departure_warning = \
            self.warner.analyse(result.left, result.right, h, w)

        # 9. annotate
        result.annotated = Visualiser.draw(frame_bgr, result, roi_pts)

        return result

    def process_video(self, input_path: str, output_path: str,
                      show_live: bool = False) -> None:
        cap = cv2.VideoCapture(input_path)
        if not cap.isOpened():
            raise IOError(f"Cannot open video: {input_path}")

        fps = cap.get(cv2.CAP_PROP_FPS) or 25
        w   = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
        h   = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
        fourcc = cv2.VideoWriter_fourcc(*"mp4v")
        writer = cv2.VideoWriter(output_path, fourcc, fps, (w, h))

        frame_idx = 0
        while True:
            ret, frame = cap.read()
            if not ret:
                break
            res = self.process_frame(frame)
            writer.write(res.annotated)
            if show_live:
                cv2.imshow("Advanced Lane Detection", res.annotated)
                if cv2.waitKey(1) & 0xFF == ord("q"):
                    break
            frame_idx += 1

        cap.release()
        writer.release()
        if show_live:
            cv2.destroyAllWindows()
        logger.info("Processed %d frames → %s", frame_idx, output_path)
